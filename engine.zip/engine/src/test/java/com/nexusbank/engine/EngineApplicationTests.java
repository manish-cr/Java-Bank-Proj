package com.nexusbank.engine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EngineApplicationTests {

	@Test
	void contextLoads() {
	}

}
